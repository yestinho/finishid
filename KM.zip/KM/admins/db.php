<?php

$con = mysqli_connect("localhost:444", "root", "", "km");
if(!$con){
  die('check your connection');
}

 ?>
