<div class="left-sidebar bg-black-300 box-shadow ">
                        <div class="sidebar-content">
                            <div class="user-info closed">
                                <?php 
                                
        $id =$_SESSION['admin'];
   $sql = "SELECT * from users where u_id=:id";
$query = $dbh->prepare($sql);
$query->bindParam(':id',$id,PDO::PARAM_STR);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query->rowCount() > 0)
{
foreach($results as $result)
{    ?>
                                <img src="images/user_img/<?php echo htmlentities($result->user_image);?>" height="50" alt="John Doe" class="img-circle profile-img">
                                <h6 class="title"><?php echo htmlentities($result->user_name);?></h6>
                                <small class="info"><?php echo htmlentities($result->role);?></small>
                            <?php } }?>
                            </div>
                            <!-- /.user-info -->

                            <div class="sidebar-nav">
                                <ul class="side-nav color-gray">
                                    <li class="nav-header">
                                        <span class="">Main Category</span>
                                    </li>
                                    <li>
                                        <a href="dashboard.php"><i class="fa fa-dashboard"></i> <span>Dashboard</span> </a>
                                     
                                    </li>

                                    <li class="nav-header">
                                        <span class="">Appearance</span>
                                    </li>
                                    
                                     <li class="has-children">
                                        <a href="#"><i class="fa fa-info-circle"></i> <span>Site Identities</span> <i class="fa fa-angle-right arrow"></i></a>
                                        <ul class="child-nav">
                                            <li><a href="logo.php"><i class="fa fa-bars"></i> <span>Update Logo </span></a></li>
                                            <li><a href="site.php"><i class="fa fa fa-server"></i> <span>Update Site Name</span></a></li>
                                        </ul>
                                    </li>

                                        <li class="has-children">
                                        <a href="#"><i class="fa fa-file-text"></i> <span>Categories</span> <i class="fa fa-angle-right arrow"></i></a>
                                        <ul class="child-nav">
                                            <li><a href="cat_add.php"><i class="fa fa-bars"></i> <span>Create Category</span></a></li>
                                            <li><a href="category.php"><i class="fa fa fa-server"></i> <span>Manage Category</span></a></li>
                                        </ul>
                                    </li>
                                    <li class="has-children">
                                        <a href="#"><i class="fa fa-book"></i> <span>Courses</span> <i class="fa fa-angle-right arrow"></i></a>
                                        <ul class="child-nav">
                                            <li><a href="course_add.php"><i class="fa fa-bars"></i> <span>Create Course</span></a></li>
                                            <li><a href="courses.php"><i class="fa fa fa-server"></i> <span>Manage Course</span></a></li>
                                           
                                        </ul>
                                    </li>
                                    <li class="has-children">
                                        <a href="#"><i class="fa fa-language"></i> <span>Sub_courses</span> <i class="fa fa-angle-right arrow"></i></a>
                                        <ul class="child-nav">
                                            <li><a href="sub_add.php"><i class="fa fa-bars"></i> <span>Add Sub_course</span></a></li>
                                            <li><a href="subcourses.php"><i class="fa fa fa-server"></i> <span>Manage Sub_course</span></a></li>
                                           
                                        </ul>
                                    </li>
                                    <li class="has-children">
                                        <a href="#"><i class="fa fa-image"></i> <span>Images</span> <i class="fa fa-angle-right arrow"></i></a>
                                        <ul class="child-nav">
                                            <li><a href="add-image.php"><i class="fa fa-bars"></i> <span>Add Image</span></a></li>
                                            <li><a href="images.php"><i class="fa fa fa-server"></i> <span>Manage Images</span></a></li>
                                           
                                        </ul>
                                    </li>
                                        
                                           
                                    <li class="has-children">
                                        <a href="#"><i class="fa fa-users"></i> <span>Users</span> <i class="fa fa-angle-right arrow"></i></a>
                                        <ul class="child-nav">
                                            <li><a href="change-password.php"><i class="fa fa-bars"></i> <span>Add User</span></a></li>
                                            <li><a href="users.php"><i class="fa fa fa-server"></i> <span>Manage Users</span></a></li>
                                           
                                        </ul>
                                    </li>
                            </div>
                            <!-- /.sidebar-nav -->
                        </div>
                        <!-- /.sidebar-content -->
                    </div>